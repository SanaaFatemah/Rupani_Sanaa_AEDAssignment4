/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UI;


import java.util.ArrayList;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.City;
import model.Community;
import model.Encounter;
import model.EncounterHistory;
import model.House;
import model.Patient;
import model.PatientDirectory;
import model.Person;
import model.PersonDirectory;
import model.VitalSigns;



  public class MainJFrame extends javax.swing.JFrame {

    /**
     * Creates new form MainJFrame
     */
    
    PersonDirectory personDirectory;
    PatientDirectory patientDirectory;
    EncounterHistory history;
    private ArrayList<Person> personDirectoryList = new ArrayList<>();
    
    public MainJFrame() {
        initComponents();
        
        personDirectory = new PersonDirectory();
        patientDirectory = new PatientDirectory();
        setData();
        //populateTable(patientDirectoryList);
    }
    
    public MainJFrame(PatientDirectory patientDirectoryList) {
        initComponents();
        
        personDirectory = new PersonDirectory();
        patientDirectory = new PatientDirectory();
//        setData();
//        populateTable(patientDirectoryList);
    }
    
    public void setData(){
        
        Person P1 = personDirectory.addNewPerson();
        String[] patientDetails1 = new String[4];
        patientDetails1[0] = "Paul Rothman";
        patientDetails1[1] = "BP";
        patientDetails1[2] = "200";
        
        createPersonOverview(P1, "Nishmita", "27 years", "Indian", "New York", 11, patientDetails1);
        
        Person P2 = personDirectory.addNewPerson();
        String[] patientDetails2 = new String[4];
        patientDetails2[0] = "Hari Kakde";
        patientDetails2[1] = "Thyroid";
        patientDetails2[2] = "201";
        
        createPersonOverview(P2, "Shwetha", "28 years", "Indian", "New Jersey", 12, patientDetails2);
        
        Person P3 = personDirectory.addNewPerson();
        String[] patientDetails3 = new String[4];
//        patientDetails2[0] = "Vidya Desai";
//        patientDetails2[1] = "PCOS";
//        patientDetails2[2] = "202";
        
        createPersonOverview(P3, "Kiara", "29 years", "Asian", "LA", 13, patientDetails3);
        
        Person P4 = personDirectory.addNewPerson();
        String[] patientDetails4 = new String[4];
        patientDetails4[0] = "Vidya Desai";
        patientDetails4[1] = "PCOS";
        patientDetails4[2] = "202";
        
        createPersonOverview(P4, "Harry", "38 years", "American", "New Jersey", 14, patientDetails4);
        
        Person P5 = personDirectory.addNewPerson();
        String[] patientDetails5 = new String[4];
        patientDetails5[0] = "Merlyn Earl";
        patientDetails5[1] = "BP";
        patientDetails5[2] = "203";
        
        createPersonOverview(P5, "Potter", "88 years", "American", "Portland", 15, patientDetails5);
        
//        P1.setAge("10 years");
//        P1.setPersonName("JohnDoe");
//        Patient patient = new Patient();
//        Encounter encounter = new Encounter();
//        
//        EncounterHistory encounterHistory = new EncounterHistory();
//        VitalSigns vitalSigns = new VitalSigns();
//            //Person person = personDirectory.addNewPerson();
//        String ag = patient.ageCalculate("10 years");
//        P1.setAgeGroup(ag);
//            
//            //P1.setAge(age);
//        House house = new House();
//        house.setCityName("Boston");
//        house.setCommunityName("Polish");
//        house.setHouseNo(20);
//        house.setSetPerson(P1);
//        house.setCommunityList(house);
//        house.setHouseList(house);
//        P1.setHouse(house);
//        createPatientOverview(P1, "Paul Rothman", "Thyroid", "201");
//        
        //P1.setVitalSign("Thyroid");
    }
//    
    private void createPersonOverview(Person P, String pName, String pAge, String pCommunity,
            String pCity, int pHouseNo, String [] patientDetails)
    {
        P.setPersonName(pName);
        Patient patient = new Patient();
        Encounter encounter = new Encounter();
        
        EncounterHistory encounterHistory = new EncounterHistory();
        VitalSigns vitalSigns = new VitalSigns();
            //Person person = personDirectory.addNewPerson();
        String ag = patient.calculateAgeGroup(pAge);
        P.setAgeGroup(ag);
        patientDetails[3] = P.getAgeGroup();
        P.setAge(pAge);
        House house = new House();
        house.setCityName(pCity);
        house.setCommunityName(pCommunity);
        house.setHouseNo(pHouseNo);
        house.setSetPerson(P);
        house.setCommunityList(house);
        house.setHouseList(house);
        P.setHouse(house);
        if (patientDetails[2] != null)
        {
            createPatientOverview(P, patientDetails);
        }
    }
    
    private void createPatientOverview(Person temp, String [] patientDetails){
        Person person = temp;
        ArrayList<Patient> PatientDirectory = new ArrayList<Patient>();
        
        Patient patient = patientDirectory.addNewPatient();
        Encounter encounter = new Encounter();
        EncounterHistory encounterHistory = new EncounterHistory();
//             if (txtDoctor.getText().isEmpty() || txtPurpose.getText().isEmpty() || txtPatientID.getText().isEmpty() ) {
//            JOptionPane.showMessageDialog(this, "Enter All Details");
//        }
//             else{
        encounter.setDoctorName(patientDetails[0]);
        encounter.setVisitedDate(new Date());
        encounter.setPurposeOfVist(patientDetails[1]);
        ArrayList<Encounter> al = new ArrayList();
        al.add(encounter);
        encounterHistory.setEncounterHistList(al);
        patient.setEncounterHistory(encounterHistory);
        patient.setAgeGroup("ADOLESCENT");
//
        patient.setPid(patientDetails[2]);
//     
//        
//        //Adding Patient to Person
        person.setPatient(patient);
        
//        PatientDirectory.add(patient);
//        patientDirectory.setPatientDirectory(PatientDirectory);
//        JOptionPane.showMessageDialog(this, "Patient added!!", "Update",
//                JOptionPane.INFORMATION_MESSAGE);
       //ArrayList<Person> personList = personDirectory.getPersonDirectory();
//        populatePatientsTable(personList);
//        
//             }
//        txtPatientID.setText("");
//        txtPurpose.setText("");
//        txtDoctor.setText("");
//        revalidate();
//            repaint();
    }
    
//    private void populateTable(PatientDirectory patientDirectoryList) {
//        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
//
//        model.setRowCount(0);
////      System.out.println("size"+ history.getHistory().size());
//
//        for (Patient patient : patientDirectoryList.getPatientDirectory()) 
//        {
//            PersonDirectory pDict = new PersonDirectory();
//            Person person = pDict.searchPatientKey(patient.getPid());
//            House house = person.getHouse();
//            //Patient patient = person.getPatient();
//            Object[] row = new Object[10];
//            row[0] = person;
//            row[1] = person.getAge();
//            row[2] = house.getCommunityName();
//            row[3] = patient.getPid();
////            row[4] = CAB.getCity();
////            row[5] = CAB.getSeats();
////            row[6] = CAB.getSerial_number();
////            row[7] = CAB.getModel_number();
////            row[8] = CAB.getCerti_year();
////
//            model.addRow(row);
////
//        }
//    }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jFrame1 = new javax.swing.JFrame();
        SplitPane = new javax.swing.JSplitPane();
        jPanel1 = new javax.swing.JPanel();
        btnPerson = new javax.swing.JButton();
        btnPatient = new javax.swing.JButton();
        btnAnalyse = new javax.swing.JButton();
        btnOverview = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        javax.swing.GroupLayout jFrame1Layout = new javax.swing.GroupLayout(jFrame1.getContentPane());
        jFrame1.getContentPane().setLayout(jFrame1Layout);
        jFrame1Layout.setHorizontalGroup(
            jFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jFrame1Layout.setVerticalGroup(
            jFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        SplitPane.setBackground(new java.awt.Color(153, 153, 153));

        jPanel1.setBackground(new java.awt.Color(204, 204, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        btnPerson.setBackground(new java.awt.Color(255, 255, 255));
        btnPerson.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        btnPerson.setForeground(new java.awt.Color(51, 51, 51));
        btnPerson.setText("PERSON");
        btnPerson.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPersonActionPerformed(evt);
            }
        });

        btnPatient.setBackground(new java.awt.Color(255, 255, 255));
        btnPatient.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        btnPatient.setText("PATIENT");
        btnPatient.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPatientActionPerformed(evt);
            }
        });

        btnAnalyse.setBackground(new java.awt.Color(255, 255, 255));
        btnAnalyse.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        btnAnalyse.setText("ANALYSE");
        btnAnalyse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAnalyseActionPerformed(evt);
            }
        });

        btnOverview.setBackground(new java.awt.Color(255, 255, 255));
        btnOverview.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        btnOverview.setText(" OVERVIEW");
        btnOverview.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnOverview.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOverviewActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnOverview, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnPatient, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnPerson, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnAnalyse, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(233, Short.MAX_VALUE)
                .addComponent(btnPerson)
                .addGap(39, 39, 39)
                .addComponent(btnPatient)
                .addGap(40, 40, 40)
                .addComponent(btnAnalyse)
                .addGap(39, 39, 39)
                .addComponent(btnOverview)
                .addGap(204, 204, 204))
        );

        SplitPane.setLeftComponent(jPanel1);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setForeground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Consolas", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(204, 204, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Patient Vital Screen");

        jLabel2.setIcon(new javax.swing.ImageIcon("C:\\Users\\hs_sa\\Desktop\\07022019-15.jpg")); // NOI18N
        jLabel2.setText("jLabel2");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(117, 117, 117)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 469, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(223, 223, 223)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 247, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(151, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 121, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(280, 280, 280))
        );

        SplitPane.setRightComponent(jPanel3);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(SplitPane, javax.swing.GroupLayout.Alignment.TRAILING)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(SplitPane)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnPersonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPersonActionPerformed
        // TODO add your handling code here:
        
           PersonJPanel Person = new PersonJPanel(personDirectory);
           SplitPane.setRightComponent(Person);         
    }//GEN-LAST:event_btnPersonActionPerformed

    private void btnPatientActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPatientActionPerformed
        // TODO add your handling code here:
        PatientJPanel Patientpanel = new PatientJPanel(personDirectory);
        SplitPane.setRightComponent(Patientpanel);
        
    }//GEN-LAST:event_btnPatientActionPerformed

    private void btnAnalyseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAnalyseActionPerformed
        // TODO add your handling code here:
        AnalyseJPanel Analysepanel = new AnalyseJPanel(personDirectory);
        SplitPane.setRightComponent(Analysepanel);
        
    }//GEN-LAST:event_btnAnalyseActionPerformed

    private void btnOverviewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnOverviewActionPerformed
        // TODO add your handling code here:
        Overview MainFrame = new Overview(patientDirectory, personDirectory);
        SplitPane.setRightComponent(MainFrame);
    }//GEN-LAST:event_btnOverviewActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainJFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JSplitPane SplitPane;
    private javax.swing.JButton btnAnalyse;
    private javax.swing.JButton btnOverview;
    private javax.swing.JButton btnPatient;
    private javax.swing.JButton btnPerson;
    private javax.swing.JFrame jFrame1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    // End of variables declaration//GEN-END:variables
}
