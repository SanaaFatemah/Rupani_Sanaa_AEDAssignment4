/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package UI;

import java.util.ArrayList;
import java.util.Date;
import javax.swing.table.DefaultTableModel;
import model.Encounter;
import model.EncounterHistory;
import model.House;
import model.Patient;
import model.PatientDirectory;
import model.Person;
import model.PersonDirectory;
import model.VitalSigns;


/**
 *
 * @author hs_sa
 */
public class Overview extends javax.swing.JPanel {

    /**
     * Creates new form Overview
     */
    
    PersonDirectory personDirectory;
    PatientDirectory patientDirectory;
    
    public Overview(PatientDirectory patientDirectoryList, PersonDirectory personDirectoryList) {
        initComponents();
        
        personDirectory = new PersonDirectory();
        patientDirectory = new PatientDirectory();
        //setData();
        populateTable(patientDirectoryList, personDirectoryList);
    }
    
    public void setData(){
        
        Person P1 = personDirectory.addNewPerson();
        String[] patientDetails1 = new String[4];
        patientDetails1[0] = "Paul Rothman";
        patientDetails1[1] = "BP";
        patientDetails1[2] = "200";
        
        createPersonOverview(P1, "Nishmita", "27 years", "Indian", "New Jersey", 11, patientDetails1);
        
        Person P2 = personDirectory.addNewPerson();
        String[] patientDetails2 = new String[4];
        patientDetails2[0] = "Hari Kakde";
        patientDetails2[1] = "Thyroid";
        patientDetails2[2] = "201";
        
        createPersonOverview(P2, "Shwetha", "27 years", "Indian", "New Jersey", 12, patientDetails2);
        
        
        
        //P1.setAge("10 years");
//        P1.setPersonName("JohnDoe");
//        Patient patient = new Patient();
//        Encounter encounter = new Encounter();
//        
//        EncounterHistory encounterHistory = new EncounterHistory();
//        VitalSigns vitalSigns = new VitalSigns();
//            //Person person = personDirectory.addNewPerson();
//        String ag = patient.ageCalculate("10 years");
//        P1.setAgeGroup(ag);
//            
//            //P1.setAge(age);
//        House house = new House();
//        house.setCityName("Boston");
//        house.setCommunityName("Polish");
//        house.setHouseNo(20);
//        house.setSetPerson(P1);
//        house.setCommunityList(house);
//        house.setHouseList(house);
//        P1.setHouse(house);
//        createPatientOverview(P1, "Paul Rothman", "Thyroid", "201");
        
        //P1.setVitalSign("Thyroid");
    }
    
    private void createPersonOverview(Person P, String pName, String pAge, String pCommunity,
            String pCity, int pHouseNo, String [] patientDetails)
    {
        P.setPersonName(pName);
        Patient patient = new Patient();
        Encounter encounter = new Encounter();
        
        EncounterHistory encounterHistory = new EncounterHistory();
        VitalSigns vitalSigns = new VitalSigns();
            //Person person = personDirectory.addNewPerson();
        String ag = patient.calculateAgeGroup(pAge);
        P.setAgeGroup(ag);
        patientDetails[3] = P.getAgeGroup();
        P.setAge(pAge);
        House house = new House();
        house.setCityName(pCity);
        house.setCommunityName(pCommunity);
        house.setHouseNo(pHouseNo);
        house.setSetPerson(P);
        house.setCommunityList(house);
        house.setHouseList(house);
        P.setHouse(house);
        createPatientOverview(P, patientDetails);
    }
    
    private void createPatientOverview(Person temp, String [] patientDetails){
        Person person = temp;
        Patient patient = new Patient();
        Encounter encounter = new Encounter();
        EncounterHistory encounterHistory = new EncounterHistory();
             
        encounter.setDoctorName(patientDetails[0]);
        encounter.setVisitedDate(new Date());
        encounter.setPurposeOfVist(patientDetails[1]);
        ArrayList<Encounter> al = new ArrayList();
        al.add(encounter);
        encounterHistory.setEncounterHistList(al);
        patient.setEncounterHistory(encounterHistory);
        //patient.setAgeGroup("ADOLESCENT");
//
        patient.setPid(patientDetails[2]);
//     
//        
//        //Adding Patient to Person
        person.setPatient(patient);
//        
    }
    
    private void populateTable(PatientDirectory patientDirectoryList, PersonDirectory personDirectoryList) {
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();

        model.setRowCount(0);

        for (Person person : personDirectoryList.getPersonDirectory())
        {
            if (person.getPatient() != null)
            {
                VitalSigns Vs = person.getVitalSign();
                if (Vs != null)
                {
                    String result = getEncounterResult(Vs, "15 years");
                    if (result == "Abnormal")
                    {
                        House house = person.getHouse();
                        Object[] row = new Object[10];
                        row[0] = person;
                        row[1] = person.getAge();
                        row[2] = house.getCommunityName();
                        row[3] = person.getPatient().getPid();
                

                    model.addRow(row);
                    }
                }
            }
        }
    }
    
    public String getEncounterResult(VitalSigns vs, String patientAge) {
        VitalSigns v = new VitalSigns(patientAge);
        if (vs.getHeartRate() >= v.gethLB() && vs.getHeartRate() < v.gethUB()
                && vs.getRespiratoryRate() >= v.getrLB() && vs.getRespiratoryRate() < v.getrUB()
                && vs.getBloodPressure() >= v.getBpLB() && vs.getBloodPressure() <= v.getBpUB()
                && vs.getWeightPounds() >= v.getWpLB() && vs.getWeightPounds() < v.getWpUB()) {
            return "Normal";
        } else {
            return "Abnormal";
        }

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(255, 255, 255));

        jScrollPane1.setBackground(new java.awt.Color(255, 255, 255));

        jTable1.setFont(new java.awt.Font("Consolas", 1, 12)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Name", "Age", "Community", "Patient ID"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Consolas", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(204, 204, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Overview");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 812, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(318, 318, 318)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(473, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
