/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


public class Community extends City {
    
    String commName;
    static HashMap<String,List<House>> mapCommunity = new HashMap();

    public static HashMap<String, List<House>> getCommunitymap() {
        return mapCommunity;
    }
    @Override
    public void setHouseList(House house)
    {
        List<House> list = mapCommunity.getOrDefault(this.getCommunityName(), new ArrayList());
        list.add(house);
        mapCommunity.put(this.getCommunityName(), list);
    }
  
    
   @Override
    public String getCommunityName() {
        return commName;
    }
   @Override
    public void setCommunityName(String communityName) {
        this.commName = communityName;
    }

}