/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.ArrayList;
import java.util.HashMap;


public class EncounterHistory {

    private ArrayList< Encounter> encHistory = new ArrayList<>();

    public EncounterHistory() {

        this.encHistory = new ArrayList<Encounter>();
    }

    public ArrayList< Encounter> getList() {
        return encHistory;
    }

    public void setEncounterHistList(ArrayList< Encounter> encounterHistory) {
        this.encHistory = encounterHistory;
    }

    public Encounter addNewEncounter() {
        Encounter encounter = new Encounter();
        encHistory.add(encounter);
        return encounter;
    }

}
