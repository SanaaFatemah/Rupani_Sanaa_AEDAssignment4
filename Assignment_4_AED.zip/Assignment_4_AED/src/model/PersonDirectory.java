/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;


import java.util.ArrayList;

public class PersonDirectory {


   private ArrayList<Person> personDirectory = new ArrayList<>();

   public PersonDirectory() {
        personDirectory = new ArrayList<>();
    }
   
    public ArrayList<Person> getPersonDirectory() {
        return personDirectory;
    }

    public void setPersonDirectory(ArrayList<Person> personDirectory) {
        this.personDirectory = personDirectory;
    }

    public Person addNewPerson() {
        Person newPerson = new Person();
        personDirectory.add(newPerson);
        return newPerson;
    }

    public void deletePerson(Person person) {
        personDirectory.remove(person);
    }

    public ArrayList<Person> searchPatient(String key)
    {
        ArrayList<Person> searchPatientDirectory = new ArrayList();
        for(Person person: personDirectory)
        {
            if(person.toString().toLowerCase().startsWith(key.toLowerCase()))
            {
                if(person.getPatient()!=null)
                {
                    searchPatientDirectory.add(person);
                }
            }
        }
        return searchPatientDirectory;
    }
    
    public Person searchPatientKey(String key)
    {
        Person searchPatientDirectory = new Person();
        for(Person person: personDirectory)
        {
            if (person.patient != null)
            {
                String PID = person.patient.getPid().toString();
                if(PID.toLowerCase().startsWith(key.toLowerCase()))
                {
                    if(person.getPatient()!=null)
                    {
                        searchPatientDirectory = person;
                        break;
                    }
                }
            }
        }
        return searchPatientDirectory;
    }
}
