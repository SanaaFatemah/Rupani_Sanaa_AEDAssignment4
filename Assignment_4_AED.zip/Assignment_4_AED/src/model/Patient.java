/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.HashMap;


public class Patient  {

    EncounterHistory encounterHistory;
    String patientID;
    String ageGroup;

    public String getAgeGroup() {
        return ageGroup;
    }

    public void setAgeGroup(String ageGroup) {
        this.ageGroup = ageGroup;
    }

    public EncounterHistory getEncounterHistory() {
        return encounterHistory;
    }

    public void setEncounterHistory(EncounterHistory encounterHistory) {
        this.encounterHistory = encounterHistory;
    }

    public String getPid() {
        return patientID;
    }

    public void setPid(String pid) {
        this.patientID = pid;
    }

    public static String calculateAgeGroup(String ageGroup) {

        String ageSplit[] = ageGroup.split(" ");
        if (ageSplit[1].equals("days")) {
            return "NEWBORN";
        } else if (ageSplit[1].equals("months")) {
            return "INFANT";
        } else if (ageSplit[1].equals("years") && Integer.parseInt(ageSplit[0]) < 3) {
            return "TODDLER";
        } else if (ageSplit[1].equals("years") && Integer.parseInt(ageSplit[0]) >= 3 && Integer.parseInt(ageSplit[0]) <= 5) {
            return "PRESCHOOLER";
        } else if (ageSplit[1].equals("years") && Integer.parseInt(ageSplit[0]) >= 6 && Integer.parseInt(ageSplit[0]) <= 12) {
            return "SCHOOLAGE";
        } else if (ageSplit[1].equals("years") && Integer.parseInt(ageSplit[0]) >= 13) {
            return "ADOLESCENT";
        }

        return "";
    }

}
