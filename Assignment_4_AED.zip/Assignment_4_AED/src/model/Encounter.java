/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.Date;


public class Encounter {

    Date visitedDate;
    String visitPurpose;
    String docName;
    VitalSigns vs;

    public VitalSigns getVitalSigns() {
        return vs;
    }

    public void setVitalSigns(VitalSigns vs) {
        this.vs = vs;
    }
    
    public Date getVisitedDate() {
        return visitedDate;
    }

    public void setVisitedDate(Date visitedDate) {
        this.visitedDate = visitedDate;
    }

    public String getPurposeOfVist() {
        return visitPurpose;
    }

    public void setPurposeOfVist(String purposeOfVist) {
        this.visitPurpose = purposeOfVist;
    }

    public String getDoctorName() {
        return docName;
    }

    public void setDoctorName(String doctorName) {
        this.docName = doctorName;
    }
    
}